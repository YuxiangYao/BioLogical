#' @title Calculate the effetive edges loading of a multi-valued function
#' @description The analysis depends on multi-valued Quine-McCluskey method 
#' [\href{https://doi.org/10.1007/s00500-007-0175-x}{Petrik,2008}] to obtain the 
#' prime implicants of input vectors belong to "f(x)=0", "f(x)=1", ..., "f(x)=i", 
#' ..., "f(x)=L-1", respectively. The results within a function can be obtained 
#' through direct and indirect methods that are equivalent. They are invisible 
#' to users and do not affect usage. Relevant concepts and definitions are found 
#' in the paper [\href{https://doi.org/10.1073/pnas.2022598118}{Gates,2021}].
#' @param aVec a vector, represents a mapping table of multi-valued function.
#' @param k an integer, k-variable of function.
#' @param L an integer, L-level multi-valued system (Default: 2, Boolean).
#' @param Detail logical, should return detail of each edge/input information? (Default: FALSE)
#' @param Redundancy logical, should return corresponding redundant values 
#' instead of effective values? (Default: FALSE)
#' @return double, effective edges of a multi-valued function
#' @export
#' @examples
#' # Calculate the effetive edges of a ternary function c(0,1,2, 0,1,2, 0,1,2).
#' # Its can be transformed to 0=f(*0), 1=f(*1), 2=f(*2)
#' # MulVFun_EffectiveEdges(c(0,1,2, 0,1,2, 0,1,2), k=2, L=3)
#' # Return 1.000 (Only lower bit can control mapping table)
#' MulVFun_EffectiveEdges(c(0,1,2, 0,1,2, 0,1,2), k=2, L=3)
#' 
#' # Calculate the effetive edges of a ternary function c(0,1,2, 0,1,2, 2,2,2).
#' # Its can be transformed to 0=f(00)|f(10), 1=f(01)|f(11), 2=f(2*)|f(*2)
#' # MulVFun_EffectiveEdges(c(0,1,2, 0,1,2, 2,2,2), k=2, L=3, Detail=TRUE)
#' # Return 0.72222 0.72222
#' # Explain the values: 0.72222
#' #  00 | 01 | 02 | 10 | 11 | 12 | 20 | 21 | 22 
#' #  00 | 01 | *2 | 10 | 11 | *2 | 2* | 2* | 2* 
#' #     |    |    |    |    |    |    |    | *2 
#' # ( 1 +  1 +  1 +  1 +  1 +  1 +  0 +  0 + 0.5 )/9 = 0.72222 # Lower one.
#' # (1  + 1  + 0  + 1  + 1  + 0  + 1  + 1  + 0.5 )/9 = 0.72222 # Higher one.
#' MulVFun_EffectiveEdges(c(0,1,2, 0,1,2, 2,2,2), k=2, L=3, Detail=TRUE)
#' 
MulVFun_EffectiveEdges<-function(aVec, k, L=2, Detail=FALSE, Redundancy=FALSE){
  a_vec=r_CheckValidMulVFun(aVec,k,L);
  if(Detail){# Show detail information
    xx=c_MulF_EffectiveEdges(a_vec,as.integer(k),as.integer(L));
  } else {# Return global information
    xx=c_MulF_Effective(a_vec,as.integer(k),as.integer(L));
  }
  if(Redundancy){# Get opposite value(s)
    if(Detail){
      xx=1.00-xx;
    }
    else {
      xx=k-xx;
    }
  }
  return(xx);
}