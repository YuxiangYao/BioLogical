// automatically generated file.
#define Z3_MAJOR_VERSION   4
#define Z3_MINOR_VERSION   11
#define Z3_BUILD_NUMBER    2
#define Z3_REVISION_NUMBER 0

#define Z3_FULL_VERSION    "Z3 4.11.2.0"
