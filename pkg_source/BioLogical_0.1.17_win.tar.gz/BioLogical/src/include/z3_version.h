// automatically generated file.
#define Z3_MAJOR_VERSION   4
#define Z3_MINOR_VERSION   14
#define Z3_BUILD_NUMBER    1
#define Z3_REVISION_NUMBER 0

#define Z3_FULL_VERSION    "Z3 4.14.1.0"
