#' @title 91 genetic networks in Kadelka's paper
#' @details List, contains all network. Each element is an independent network.
#' The number is original reference. For example, \code{k_11082279} represents the paper, PMID_11082279.
#' One network is also organized as a \code{List}:
#'  \itemize{
#'   \item \code{AllMember}: \code{CharacterVector}, all genes' name
#'   \item \code{InEdge}: \code{IntegerVector}, Input regulations by order. No input is denoted as \code{NA}. In each vector, first element is highest bit.
#'   \item \code{OutEdge}: \code{IntegerVector}, Output regulations by order. No output is denoted as \code{NA}.
#'   \item \code{BoolFun}: \code{IntegerVector}, Boolean function of each genes (length=2^length(\code{InEdge})). If \code{InEdge} is \code{NA}, it also keeps \code{NA}.
#' }
#' Detail information, please see original paper \href{https://doi.org/10.1126/sciadv.adj0822}{Kadelka2024}
#' @usage
#' data(BoolGRN_KadelkaSet)
"BoolGRN_KadelkaSet"
