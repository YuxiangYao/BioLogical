#' @title 70 genetic networks selected from Cell Collective database
#' @description A list containing networks from the database, with each element 
#' representing an independent network. The number is consistent with that 
#' provided on the website. For example, \code{c_11863} refers to the biological
#' network No.11863.
#' @details 
#' Each network is organized as a four-element formatted list:
#' \itemize{
#'   \item \code{AllMember}: a \code{CharacterVector} that record all names of gene.
#'   \item \code{InEdge}: a \code{list} of \code{IntegerVector}; each vector 
#' records the indices of input control nodes for each node, with the first 
#' element corresponding to the highest bit in the truth table. No input is 
#' denoted as \code{NA}.
#'   \item \code{OutEdge}: a \code{list} of \code{IntegerVector}; each vector 
#' records downstream nodes. No output is denoted as \code{NA}.
#'   \item \code{BoolFun}: a \code{list} of \code{IntegerVector}; each vector 
#' represents the Boolean function with length of (\code{BoolFun[[i]]} is identical to
#' \code{2^length(InEdge[[i]])}). If the coressponing \code{InEdge[[i]]} is 
#' \code{NA}, it remains \code{NA}.}
#' Please note that node indices start from 0 rather than 1. Other detail 
#' information about the database, please see 
#' \href{https://cellcollective.org}{Cell Collective Website}.
#' @usage
#' data(BoolGRN_CellCollective)
#' @format
#' A list of genetic networks.
"BoolGRN_CellCollective"
